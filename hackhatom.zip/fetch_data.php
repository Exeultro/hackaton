<?php
header('Content-Type: application/json'); // Указываем, что возвращаем JSON

// Подключение к базе данных
$servername = "localhost"; // Замените на ваш сервер
$username = "root"; // Замените на ваше имя пользователя
$password = "toor"; // Замените на ваш пароль
$dbname = "flight_data"; // Замените на имя вашей базы данных

// Создание подключения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка подключения
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Получаем параметры запроса
$flightType = $_GET['type'] ?? 'all';
$searchQuery = $_GET['search'] ?? '';
$dateQuery = $_GET['date'] ?? '';

// Преобразуем дату в формат ДД-ММ-ГГГГ
if (!empty($dateQuery)) {
    $dateQuery = date('Y-m-d', strtotime($dateQuery)); // Преобразуем в формат YYYY-MM-DD для SQL
}

// Формируем SQL-запрос
$sql = "SELECT serial_number, bort_id, flight_type, date, flight_hours, responsible, comments FROM flight_data";
$conditions = [];

// Добавляем условия фильтрации
if ($flightType !== 'all') {
    $conditions[] = "flight_type = '" . $conn->real_escape_string($flightType) . "'";
}
if (!empty($searchQuery)) {
    $conditions[] = "(serial_number LIKE '%" . $conn->real_escape_string($searchQuery) . "%' OR 
                     comments LIKE '%" . $conn->real_escape_string($searchQuery) . "%' OR 
                     responsible LIKE '%" . $conn->real_escape_string($searchQuery) . "%')";
}
if (!empty($dateQuery)) {
    $conditions[] = "date = '" . $conn->real_escape_string($dateQuery) . "'";
}

// Если есть условия, добавляем их к запросу
if (count($conditions) > 0) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

// Выполняем запрос
$result = $conn->query($sql);

// Проверяем, есть ли результаты
$flights = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $flights[] = [
            'serial' => $row['serial_number'],
            'id' => $row['bort_id'], // Предполагается, что bort_id используется как id
            'type' => $row['flight_type'],
            'date' => $row['date'],
            'hours' => $row['flight_hours'],
            'responsible' => $row['responsible'],
            'comments' => $row['comments'],
            'log' => $row['bort_id'] // Или любое другое поле, которое вы хотите использовать для логов
        ];
    }
}

// Возвращаем данные в формате JSON
echo json_encode(array_values($flights));

// Закрываем соединение
$conn->close();
?>