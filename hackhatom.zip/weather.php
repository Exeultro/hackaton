function checkWeather($date) {
    $apiKey = 'YOUR_YANDEX_API_KEY'; // Замените на ваш API-ключ
    $url = "https://api.weather.yandex.ru/v2/forecast?lat=55.7558&lon=37.6173&date=" . $date;

    $headers = [
        "X-Yandex-API-Key: $apiKey"
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    $weatherData = json_decode($response, true);
    return $weatherData['fact']['wind_speed'] ?? 0; // Возвращаем скорость ветра
}