// Функция для генерации более плавных данных с экспоненциальным сглаживанием

function generateSmoothData(length, range, smoothness = 0.8) { // Уменьшаем сглаживание
    const data = [];
    let currentValue = (Math.random() - 0.5) * 2 * range;
    for (let i = 0; i < length; i++) {
      const change = (Math.random() - 0.5) * 0.2 * range; // Уменьшаем диапазон изменения
      currentValue = currentValue * smoothness + change * (1 - smoothness);
      data.push(currentValue);
    }
    return data;
  }
  
  // Функция для генерации данных для графика напряжения батареи
  function generateBatteryData(length, rollData, pitchData, yawData) {
    const data = [];
    let voltage = 12.6; // Начальное напряжение (полностью заряжена)
    const baseDischargeRate = 0.0005; // Базовая скорость разряда
    const controlInfluence = 0.0015; // Влияние управления на разряд (увеличиваем)
    const recoveryRate = 0.0001; // Скорость восстановления напряжения
    const spikeFactor = 2; // Увеличиваем просадки
  
    for (let i = 0; i < length; i++) {
      // Рассчитываем дополнительный разряд в зависимости от интенсивности управления
      const controlDischarge = controlInfluence * (Math.abs(rollData[i]) + Math.abs(pitchData[i]) + Math.abs(yawData[i]));
  
      // Если управление активно, делаем просадку более выраженной
      let totalDischarge = baseDischargeRate + controlDischarge;
      if (Math.abs(rollData[i]) + Math.abs(pitchData[i]) + Math.abs(yawData[i]) > 0.2) {
        totalDischarge *= spikeFactor; // Увеличиваем просадку в несколько раз
      }
  
      // Уменьшаем напряжение
      voltage -= totalDischarge;
  
      // Добавляем небольшое восстановление, если управление не активно
      if (Math.abs(rollData[i]) + Math.abs(pitchData[i]) + Math.abs(yawData[i]) < 0.1) {
        voltage += recoveryRate;
      }
  
      // Ограничиваем минимальным значением
      if (voltage < 10.5) { // Минимальное напряжение (полностью разряжена)
        voltage = 10.5;
      }
      data.push(voltage);
    }
    return data;
  }
  
  // Пример данных для roll, yaw и pitch
  const timeLabels = Array.from({ length: 1000 }, (_, i) => i); // Укороченные временные метки
  const rollData = generateSmoothData(1000, 0.5); // Roll, уменьшаем диапазон
  const yawData = generateSmoothData(1000, 0.01); // Yaw, уменьшаем диапазон
  const pitchData = generateSmoothData(1000, 0.5); // Pitch, уменьшаем диапазон
  
  // Данные для напряжения батареи
  const batteryData = generateBatteryData(1000, rollData, pitchData, yawData);
  
  // Данные для графика углов полета
  const flightData = {
    labels: timeLabels,
    datasets: [{
      label: "Roll",
      data: rollData,
      borderColor: "rgba(255, 0, 0, 1)", // Красный
      borderWidth: 0.5,
      pointRadius: 0, // Убираем точки
      fill: false,
      tension: 0.4, // Добавляем сглаживание
    },
    {
      label: "Yaw",
      data: yawData,
      borderColor: "rgba(0, 0, 255, 1)", // Синий
      borderWidth: 0.5,
      pointRadius: 0, // Убираем точки
      fill: false,
      tension: 0.4, // Добавляем сглаживание
    },
    {
      label: "Pitch",
      data: pitchData,
      borderColor: "rgba(0, 255, 0, 1)", // Зеленый
      borderWidth: 0.5,
      pointRadius: 0, // Убираем точки
      fill: false,
      tension: 0.4, // Добавляем сглаживание
    },
    ],
  };
  
  // Данные для графика напряжения батареи
  const batteryChartData = {
    labels: timeLabels,
    datasets: [{
      label: "Battery",
      data: batteryData,
      borderColor: "rgba(255, 200, 50, 1)", // Желтый
      borderWidth: 1,
      pointRadius: 0, // Убираем точки
      fill: false,
      tension: 0.4, // Добавляем сглаживание
    },],
  };
  
  // Настройки для графика углов полета
  const flightOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        title: {
          display: false,
          text: "Значение",
        },
        grid: {
          color: "rgba(200, 200, 200, 0.2)",
        },
        beginAtZero: false, // Чтобы ось Y не начиналась с нуля
      },
      x: {
        title: {
          display: false,
          text: "Время",
        },
        grid: {
          color: "rgba(200, 200, 200, 0.2)",
        },
      },
    },
    layout: {
      padding: {
        left: 10,
        right: 10,
        top: 10,
        bottom: 10
      }
    },
    plugins: {
      legend: {
        display: false,
      },
    },
  };
  
  // Настройки для графика напряжения батареи
  const batteryOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        title: {
          display: false,
          text: "Напряжение (В)",
        },
        grid: {
          color: "rgba(200, 200, 200, 0.2)",
        },
        beginAtZero: false, // Чтобы ось Y не начиналась с нуля
      },
      x: {
        title: {
          display: false,
          text: "Время",
        },
        grid: {
          color: "rgba(200, 200, 200, 0.2)",
        },
      },
    },
    layout: {
      padding: {
        left: 10,
        right: 10,
        top: 10,
        bottom: 10
      }
    },
    plugins: {
      legend: {
        display: false,
      },
    },
  };
  
  // Создание графика углов полета
  const flightCtx = document.getElementById("flightChart").getContext("2d");
  const flightChart = new Chart(flightCtx, {
    type: "line",
    data: flightData,
    options: flightOptions,
  });
  
  
  
  // Дополнительный код для графика управления дроном
  const droneControlData = {
    labels: timeLabels,
    datasets: [{
      label: "Drone Control",
      data: rollData.map((value, index) => value + pitchData[index] + yawData[index]), // Пример данных
      borderColor: "rgb(191, 255, 0)", // Красный
      borderWidth: 1,
      pointRadius: 0, // Убираем точки
      fill: false,
      tension: 0.4, // Добавляем сглаживание
    }],
  };
  
  // Настройки для графика управления дроном
  const droneControlOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        title: {
          display: false,
          text: "Управление",
        },
        grid: {
          color: "rgba(200, 200, 200, 0.2)",
        },
        beginAtZero: false,
      },
      x: {
        title: {
          display: false,
          text: "Время",
        },
        grid: {
          color: "rgba(200, 200, 200, 0.2)",
        },
      },
    },
    layout: {
      padding: {
        left: 10,
        right: 10,
        top: 10,
        bottom: 10
      }
    },
    plugins: {
      legend: {
        display: false,
      },
    },
  };
  
  // Соз дание графика управления дроном
  const droneControlCtx = document.getElementById("droneControlChart").getContext("2d");
  const droneControlChart = new Chart(droneControlCtx, {
    type: "line",
    data: droneControlData,
    options: droneControlOptions,
  });
  
// Обработчик для кнопки скачивания логов
document.getElementById("downloadLogs").addEventListener("click", function() {
    // Создаем ссылку на файл
    const link = document.createElement('a');
    link.href = './log.txt'; // Путь к файлу
    link.download = 'logё.txt'; // Имя файла при скачивании
    document.body.appendChild(link); // Добавляем ссылку в DOM
    link.click(); // Имитируем клик по ссылке
    document.body.removeChild(link); // Удаляем ссылку из DOM
});

// Обработчик для кнопки скачивания системных логов
document.getElementById("downloadSystemLogs").addEventListener("click", function() {
    // Создаем ссылку на файл
    const link = document.createElement('a');
    link.href = './logsys.txt'; // Путь к файлу
    link.download = 'system_logs.txt'; // Имя файла при скачивании
    document.body.appendChild(link); // Добавляем ссылку в DOM
    link.click(); // Имитируем клик по ссылке
    document.body.removeChild(link); // Удаляем ссылку из DOM
});

