<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получение данных из формы
    $serialNumber = $_POST['serial_number'];
    $bortId = $_POST['bort_id'];
    $flightType = $_POST['flight_type'];
    $date = $_POST['date'];
    $flightHours = $_POST['flight_hours'];
    $responsible = $_POST['responsible'];
    $comments = $_POST['comments'];

    // Обработка загрузки файлов
    $targetDir = "uploads/"; // Папка для загрузки файлов

    // Проверка, существует ли папка, если нет - создаем
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $uploadOk = 1;

    // Обработка каждого загруженного файла
    foreach ($_FILES['file']['name'] as $key => $name) {
        $targetFile = $targetDir . basename($name);
        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Проверка на существование файла
        if (file_exists($targetFile)) {
            echo "Извините, файл $name уже существует.<br>";
            $uploadOk = 0;
            continue; // Пропускаем этот файл
        }

        // Проверка на ошибки
        if ($_FILES['file']['error'][$key] !== UPLOAD_ERR_OK) {
            echo "Ошибка при загрузке файла $name.<br>";
            $uploadOk = 0;
            continue; // Пропускаем этот файл
        }

        // Перемещение загруженного файла в целевую папку
        if (move_uploaded_file($_FILES['file']['tmp_name'][$key], $targetFile)) {
            echo "Файл " . htmlspecialchars(basename($name)) . " был загружен.<br>";
        } else {
            echo "Извините, произошла ошибка при загрузке файла $name.<br>";
        }
    }

    if ($uploadOk == 0) {
        echo "Некоторые файлы не были загружены.";
    } else {
        // Подключение к базе данных
        $servername = "localhost"; // Замените на ваш сервер
        $username = "root"; // Замените на ваше имя пользователя
        $password = "toor"; // Замените на ваш пароль
        $dbname = "flight_data"; // Замените на имя вашей базы данных

        // Создание подключения
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Проверка подключения
        if ($conn->connect_error) {
            die("Ошибка подключения: " . $conn->connect_error);
        }

        // Подготовка и выполнение SQL-запроса
        $stmt = $conn->prepare("INSERT INTO flight_data (serial_number, bort_id, flight_type, date, flight_hours, responsible, comments) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssids", $serialNumber, $bortId, $flightType, $date, $flightHours, $responsible, $comments);

        if ($stmt->execute()) {
            echo "Данные успешно сохранены.";
        } else {
            echo "Ошибка при сохранении данных: " . $stmt->error;
        }

        // Закрытие соединения
        $stmt->close();
        $conn->close();
    }
}
?>