async function fetchFlights() {
    const flightType = document.getElementById("flightType").value;
    const searchQuery = document.getElementById("search").value;
    const dateQuery = document.getElementById("date").value; // Получаем значение даты

    const response = await fetch(`fetch_data.php?type=${flightType}&search=${searchQuery}&date=${dateQuery}`);
    const data = await response.json();
    renderTable(data);
}

function renderTable(data) {
    const tableBody = document.querySelector("#flightTable tbody");
    tableBody.innerHTML = ""; // Очистка таблицы

    data.forEach(flight => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${flight.serial}</td>
            <td>${flight.id}</td>
            <td>${flight.type}</td>
            <td>${flight.date}</td>
            <td>${flight.hours}</td>
            <td>${flight.responsible}</td>
            <td>${flight.comments}</td>
            <td><a href="logo.html">${flight.log}</a></td>
        `;
        tableBody.appendChild(row);
    });
}

document.addEventListener("DOMContentLoaded", () => {
    fetchFlights(); // Загрузка данных при старте
});

document.getElementById("applyFilters").addEventListener("click", fetchFlights);